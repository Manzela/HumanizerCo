# HumanizerCo — Assignment #3: the ad creatives, and why

*Daniel Manzela · Assignment #3, reasoning write-up*

## The bet

Search traffic was warm — those people typed "free ai humanizer" and our ad just had to show up. Display, Instagram and TikTok are the opposite: nobody asked for us, so the creative has to earn a click from someone mid-scroll. So every idea leads with the one thing this product can *prove* in a single frame and a slogan can't — the AI-detection estimate visibly falling — and it keeps the landing page's honest voice (no "undetectable", the score labelled an estimate). This audience has been burned by tools that oversell; a claim they can disprove in ten seconds kills the click-through-to-signup the whole funnel depends on. I built three directions, each in light and dark, so we can test which one stops the scroll.

## 1 · The Drop — my lead

This is the product's core loop compressed into one image: a number falling from **98% to 9% AI**, with the same meter and "Human ≤ 25%" marker from the page. I lead with it because cold traffic needs a reason to believe *fast*, and a quantified before/after is concrete proof where a headline is just a promise — it reads like a progress bar that's almost finished, which is exactly the tension that earns the tap. It also pre-sells the result, so the click arrives already wanting the outcome. The honest microcopy ("paste into any detector to verify") stays on the big format so the proof never tips into a claim we can't back. If we run one design across the whole campaign, it's this one.

## 2 · The Rewrite

This shows the *mechanic* instead of the score: robotic AI text with the tells struck through — delve into, intricate realm, leverage, underscore — turning into plain human writing. It exists for the slice of the audience who don't actually know what a "humanizer" does; it answers "what will this do to my text" before they ever click. The red-to-green, before-to-after layout is legible in half a second, and because it demonstrates the value rather than asserting it, it carries the brand's credibility better than any adjective. It's the strongest pick for broad, less-aware placements where education drives the click.

## 3 · Bold & Free

The aggressive test: **"Sound 100% human."** at maximum size, leading with the two biggest friction-killers for a cold audience — *free* and *private / in your browser*. It mirrors the desire behind the original search rather than the modest control, so it's the one most likely to win raw attention, and the giant type is built to stop a thumb in a busy feed. I kept a small 98→9 proof strip on it so the bold claim still has an anchor and doesn't read as empty hype. This is the variant I'd pit against The Drop to find out whether this audience rewards boldness or honesty — the same question from Assignment #2's headline test, now in-feed.

## Format & treatment notes

Each direction is adapted to all three sizes: the **320×50** banner strips to mark + one-line hook + CTA (the score survives here as "98% → 9% AI" where a full sentence wouldn't); the **250×250** square gets a headline, the proof graphic, and a full-width button; the **1080×1920** is the flagship — full hero, the proof at scale, and a thumb-reachable CTA kept clear of the Stories/Reels safe zones. On light vs dark: I'd run **dark in social feeds and Stories** (it stops the scroll and reads premium against UGC) and **light for Display banners** that sit on white publisher pages. Recommended first flight: **The Drop** at all three sizes for a consistent campaign, with **Bold & Free (dark)** as the primary creative test against it.
